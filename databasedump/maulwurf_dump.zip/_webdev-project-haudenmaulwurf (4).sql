-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 18. Apr 2020 um 16:27
-- Server-Version: 10.4.11-MariaDB
-- PHP-Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `/webdev-project-haudenmaulwurf`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `score`
--

CREATE TABLE `score` (
  `id` int(10) UNSIGNED NOT NULL,
  `points` int(11) NOT NULL,
  `tmsp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `user_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `score`
--

INSERT INTO `score` (`id`, `points`, `tmsp`, `user_id`) VALUES
(1, 25, '2020-04-02 10:31:15', 11),
(9, 15, '2020-04-04 15:43:04', 11),
(10, 10, '2020-04-12 10:12:52', 11),
(11, 16, '2020-04-12 10:13:10', 11),
(12, 17, '2020-04-12 10:14:13', 11),
(13, 20, '2020-04-12 10:16:09', 11),
(14, 13, '2020-04-12 10:17:17', 11),
(15, 0, '2020-04-12 10:17:56', 11),
(16, 9, '2020-04-12 10:21:07', 11),
(17, 10, '2020-04-12 10:22:32', 11),
(18, 10, '2020-04-12 10:22:53', 11),
(19, 0, '2020-04-12 10:23:09', 11),
(20, 16, '2020-04-12 10:38:09', 11),
(21, 14, '2020-04-12 10:45:49', 11),
(22, 12, '2020-04-12 11:00:52', 11),
(23, 15, '2020-04-12 11:16:01', 5),
(24, 18, '2020-04-12 11:16:20', 5),
(25, 0, '2020-04-12 11:37:00', 11),
(26, 18, '2020-04-12 12:02:29', 11),
(27, 19, '2020-04-12 12:02:49', 11),
(28, 11, '2020-04-12 12:03:12', 11),
(29, 21, '2020-04-12 12:03:30', 11),
(30, 12, '2020-04-12 12:31:46', 11),
(31, 18, '2020-04-12 12:44:53', 11),
(32, 22, '2020-04-12 12:45:13', 11),
(33, 17, '2020-04-12 12:50:12', 5),
(34, 19, '2020-04-12 12:50:30', 5),
(35, 21, '2020-04-12 12:50:46', 5),
(36, 16, '2020-04-12 12:56:56', 5),
(37, 22, '2020-04-12 12:57:13', 5),
(38, 14, '2020-04-12 15:23:25', 12),
(39, 18, '2020-04-12 15:31:32', 12),
(40, 22, '2020-04-12 15:31:51', 12),
(41, 18, '2020-04-13 09:18:48', 12),
(42, 14, '2020-04-13 09:19:14', 12),
(43, 18, '2020-04-13 09:19:30', 12),
(44, 17, '2020-04-13 09:42:21', 12),
(45, 16, '2020-04-13 09:42:40', 12),
(46, 4, '2020-04-13 09:43:05', 12),
(47, 15, '2020-04-13 10:11:17', 12),
(48, 16, '2020-04-13 10:11:35', 12),
(49, 17, '2020-04-13 10:11:51', 12),
(50, 18, '2020-04-13 10:12:15', 12),
(51, 25, '2020-04-13 10:44:27', 12),
(52, 19, '2020-04-16 08:38:56', 12),
(53, 18, '2020-04-16 08:43:31', 12),
(54, 20, '2020-04-16 08:43:48', 12),
(55, 18, '2020-04-16 09:07:20', 12),
(56, 16, '2020-04-16 09:07:35', 12),
(57, 17, '2020-04-16 09:07:52', 12),
(58, 20, '2020-04-16 09:08:08', 12),
(59, 20, '2020-04-16 09:10:52', 12),
(60, 10, '2020-04-16 09:12:02', 12),
(61, 15, '2020-04-16 09:13:44', 12),
(62, 13, '2020-04-16 09:14:10', 12),
(63, 17, '2020-04-16 14:12:34', 12),
(64, 14, '2020-04-16 14:13:47', 12),
(65, 16, '2020-04-16 14:22:05', 12),
(66, 18, '2020-04-16 14:22:21', 12),
(67, 23, '2020-04-16 14:22:37', 12),
(68, 11, '2020-04-16 14:25:36', 12),
(69, 8, '2020-04-16 14:25:52', 12),
(70, 18, '2020-04-16 14:26:07', 12),
(71, 18, '2020-04-16 14:26:23', 12),
(72, 17, '2020-04-16 14:26:38', 12),
(73, 15, '2020-04-16 14:26:53', 12),
(74, 18, '2020-04-16 14:27:09', 12),
(75, 36, '2020-04-18 07:56:02', 13),
(76, 52, '2020-04-18 07:58:03', 13),
(77, 42, '2020-04-18 08:44:03', 13),
(78, 46, '2020-04-18 10:05:41', 13),
(79, 0, '2020-04-18 10:24:52', 13),
(80, 56, '2020-04-18 14:24:37', 16),
(81, 52, '2020-04-18 14:25:16', 16),
(82, 49, '2020-04-18 14:25:57', 11),
(83, 49, '2020-04-18 14:26:39', 5);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user`
--

CREATE TABLE `user` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `user`
--

INSERT INTO `user` (`id`, `name`, `password`) VALUES
(1, 'Jason', '$2y$10$sbWJ77.MBJXg0ad95GVKgukoz6yHiwOoaL2N4eLR7OaiOOgc/PRNa'),
(2, 'Julia', '$2y$10$j13lwPCSUihW7Z15LVrSGOf5uoZmQhUntLNkNXnBYYidPZSbuC9B2'),
(3, 'Hans', '$2y$10$mkhCAoQYHVcFXYBKPIFTUuvOwu/CDeiFXInX8K0fL9XkDDC9LEqpO'),
(4, 'Dorie', '$2y$10$7lE/IB7FtsLch76Eqzc4Oe/5nfGbZNsKFm1w21eaNlKuGHVi7..Di'),
(5, 'test', '$2y$10$7Z3Iq0Zl.WIiNH7t8bk39OYVp3T6ICb2dF7yYAhhEaUMiFKbh3apq'),
(6, 'Sabine', '$2y$10$U8fdL8E8AITNMSnC9dKQkuQGiSaDfWBjt8a1hYTwXG2JdQkTVTtfW'),
(7, 'versuch', '$2y$10$tpqsC6rSu86NYkIzP/rJ0OJh5xwqaLAKut9nBQRtaruVfNVaUUUvG'),
(8, 'qwertzui', '$2y$10$5RDNAjO/lZqkTC9zazcA6uG.PFdVUENm0UBPAmJHolnjgl8sn8.5i'),
(9, 'asdfghjkl', '$2y$10$mOZzxMjiqRtDbBoNtCmgVOQWhuj4pKX104mAxJLqhjrDFymQptnPq'),
(10, 'test2', '$2y$10$t7MaTFECfNle8TxSlBve/eCNrR7jlMIOKSLUv74BzYfG1qbdqXXiK'),
(11, 'Claudia', '$2y$10$csrqudV2zOpQApB4DFaZgeUlARKExAX20j0pHHIPeQ8.3ijo4kJny'),
(12, 'Ascher', '$2y$10$6eubZNfrrgEbBccguA3Blu3z/b7t8rYYCmbswAabOHPOCleci7w2u'),
(13, 'Sabi', '$2y$10$9Kdsk9o80STX5myv1bduhuWYtT0XINNW7aXuwQbkJ2rQeO.isMcga'),
(14, ' probe', '$2y$10$.CD3hFMYgvOTl9Wyde1e5OyyCGQdYVLtIYsmf7g7jb8bMk9Yg9AUe'),
(15, 'Sabine8', '$2y$10$u3EGXnw3cjAf2aOwk/2Tr.J6i9ss48rwK8k6X7X5G2.bz3SsukFva'),
(16, 'probe', '$2y$10$jr5o9c65PglcloAi.MPPAO18/U/TmH/vIedzXuesJHJ.JylOsfVyW');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `score`
--
ALTER TABLE `score`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indizes für die Tabelle `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `score`
--
ALTER TABLE `score`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT für Tabelle `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `score`
--
ALTER TABLE `score`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
